Refer the README.txt in src folder for setting up the environment.
