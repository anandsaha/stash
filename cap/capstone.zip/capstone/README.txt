This is my submission towards the capstone project for MLND.

Find in this submission:

1. Capstone Project Report: project_report.pdf
2. Capstone Proposal: proposal.pdf
3. Capstone Proposal successful review link: https://review.udacity.com/#!/reviews/645929
4. Codebase: src/ folder here contains the source code

-> Refer the src/README.txt file in src folder for setting up the environment and executing the program.

A video of the model getting trained is here: youtu.be/yDugh3WH24M

-Anand
