# aind-sudoku
### Solving the Sudoku game using AI - project for Udacity's AI Nanodegree program


##### This repository will contain:

1. A Jupyter notebook demonstrating various aspects of solving the game, along with solutions.
2. A python module for the same which can be pluged into higher level applications solving the Sudoku.
3. A RESTful web service which exposes an API which can be invoked to solve the Sudoku. Makes use of the python module above. 

-Anand
