# ai-algos-python
My practice implementation of various AI algorithms in Python (Mostly from the AIMA 3ed book)
