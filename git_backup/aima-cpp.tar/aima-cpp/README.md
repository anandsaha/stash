# aima-cpp
C++ implementation of the algorithms in "AI  a Modern Approach, 3rd Ed"
